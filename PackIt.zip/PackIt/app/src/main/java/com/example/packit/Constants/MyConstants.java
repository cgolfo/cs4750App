package com.example.packit.Constants;

public class MyConstants {

    public static final String MY_SELECTIONS = "My Selections";

    public static final String TRUE_STRING = "true";

    public static final String FALSE_STRING = "false";

    public static final String HEADER_SMALL = "header";

    public static final String SHOW_SMALL = "show";

    public static final String USER_SMALL = "user";

    public static final String SYSTEM_SMALL = "system";

    public static final String BASIC_NEEDS_CAMEL_CASE = "Basic Needs";

    public static final String CLOTHING_CAMEL_CASE = "Clothing";

    public static final String PERSONAL_CARE_CAMEL_CASE = "Personal Care";

    public static final String BABY_NEEDS_CAMEL_CASE = "Baby Needs";

    public static final String HEALTH_CAMEL_CASE = "Health";

    public static final String TECHNOLOGY_CAMEL_CASE = "Technology";

    public static final String FOOD_CAMEL_CASE = "Food";

    public static final String BEACH_SUPPLIES_CAMEL_CASE = "Beach Supplies";

    public static final String CAR_SUPPLIES_CAMEL_CASE = "Car Supplies";

    public static final String NEEDS_CAMEL_CASE = "Needs";

    public static final String MY_LIST_CAMEL_CASE = "My List";

    public static final String MY_SELECTIONS_CAMEL_CASE = "My Selections";

    public static final String FIRST_TIME_CAMEL_CASE = "firstTime";
}
